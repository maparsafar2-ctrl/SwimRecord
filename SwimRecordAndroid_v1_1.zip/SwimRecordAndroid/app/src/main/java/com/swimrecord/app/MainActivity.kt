package com.swimrecord.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pool
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF071B35)
private val Blue = Color(0xFF168BCE)
private val Panel = Color(0xFF102B4A)

private data class Record(
    val region: String,
    val group: String,
    val sex: String,
    val event: String,
    val pool: String,
    val time: String,
    val swimmer: String,
    val meet: String,
    val date: String,
    val source: String,
    val verified: Boolean = true
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SwimRecordApp() }
    }
}

@Composable
private fun SwimRecordApp() {
    val context = LocalContext.current
    var region by remember { mutableStateOf("جهان") }
    var ageGroup by remember { mutableStateOf("بزرگسالان") }
    var sex by remember { mutableStateOf("مردان") }
    var stroke by remember { mutableStateOf("آزاد") }
    var distance by remember { mutableStateOf("۵۰ متر") }
    var pool by remember { mutableStateOf("۵۰ متری") }
    var search by remember { mutableStateOf("") }

    val records = remember {
        listOf(
            Record("جهان", "بزرگسالان", "مردان", "۵۰ متر آزاد", "۵۰ متری", "۲۰٫۸۸ ثانیه", "کامرون مک‌اوی", "China Swimming Open، شنژن", "۲۰ مارس ۲۰۲۶", "https://www.worldaquatics.com/news/4474806/swimming-world-record-cameron-mcevoy-breaks-iconic-50m-freestyle-world-record-cesar-cielo"),
            Record("جهان", "بزرگسالان", "زنان", "۵۰ متر آزاد", "۵۰ متری", "۲۳٫۵۵ ثانیه", "گرتچن والش", "Sette Colli، رم", "۲۰۲۶", "https://www.worldaquatics.com/news/4561409/kate-douglass-has-found-her-best-event"),
        )
    }

    val filtered = records.filter {
        it.region == region && it.group == ageGroup && it.sex == sex &&
            it.pool == pool && it.event.contains(distance) && it.event.contains(stroke) &&
            (search.isBlank() || it.swimmer.contains(search, true) || it.event.contains(search, true))
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Navy, surface = Panel)) {
        Scaffold(containerColor = Navy) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 18.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Pool, contentDescription = null, tint = Blue, modifier = Modifier.size(36.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("SwimRecord", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Text("بانک رکوردهای شنا | نسخه ۱٫۱", color = Color(0xFFB8CBE0), fontSize = 12.sp)
                        }
                    }
                }
                item { Text("جست‌وجوی رکورد", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                item {
                    Text("محدوده", color = Color(0xFFB8CBE0))
                    ChoiceRow(listOf("جهان", "ایران"), region) { region = it }
                }
                item {
                    Text("رده سنی", color = Color(0xFFB8CBE0))
                    ChoiceRow(listOf("بزرگسالان", "۱۵ تا ۱۷ سال"), ageGroup) { ageGroup = it }
                }
                item {
                    Text("جنسیت", color = Color(0xFFB8CBE0))
                    ChoiceRow(listOf("مردان", "زنان"), sex) { sex = it }
                }
                item {
                    Text("سبک شنا", color = Color(0xFFB8CBE0))
                    ChoiceRow(listOf("آزاد", "پشت", "قورباغه", "پروانه"), stroke) { stroke = it }
                }
                item {
                    Text("مسافت", color = Color(0xFFB8CBE0))
                    ChoiceRow(listOf("۵۰ متر", "۱۰۰ متر", "۲۰۰ متر"), distance) { distance = it }
                }
                item {
                    Text("نوع استخر", color = Color(0xFFB8CBE0))
                    ChoiceRow(listOf("۵۰ متری", "۲۵ متری"), pool) { pool = it }
                }
                item {
                    OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                        singleLine = true, placeholder = { Text("جست‌وجوی نام شناگر یا ماده") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) })
                }
                item { Text("نتایج", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                if (filtered.isEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("رکورد تأییدشده‌ای برای این فیلتر در نسخه فعلی ثبت نشده است.", color = Color.White, fontWeight = FontWeight.SemiBold)
                                Spacer(Modifier.height(6.dp))
                                Text("به‌خصوص رکوردهای رده ۱۵ تا ۱۷ سال باید از جدول رسمی همان رده و جنسیت وارد شوند؛ این برنامه زمان تخمینی را به‌جای رکورد رسمی نشان نمی‌دهد.", color = Color(0xFFB8CBE0), fontSize = 12.sp)
                            }
                        }
                    }
                } else {
                    items(filtered) { record ->
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(record.event + " | استخر " + record.pool, color = Color(0xFF8ED7FF), fontWeight = FontWeight.Bold)
                                Text(record.time, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                                Text("شناگر: ${record.swimmer}", color = Color.White)
                                Text("مسابقه: ${record.meet}", color = Color(0xFFB8CBE0), fontSize = 12.sp)
                                Text("تاریخ: ${record.date}", color = Color(0xFFB8CBE0), fontSize = 12.sp)
                                Text("منبع: World Aquatics", color = Color(0xFFB8CBE0), fontSize = 12.sp)
                                TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(record.source))) }) { Text("مشاهده منبع رسمی") }
                            }
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF183653)), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("درباره دقت اطلاعات", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("اطلاعاتی که هنوز از سند رسمی قابل بررسی استخراج نشده‌اند، خالی می‌مانند. رکوردهای جهان و ایران و همچنین استخر ۲۵ و ۵۰ متری با هم مخلوط نمی‌شوند.", color = Color(0xFFB8CBE0), fontSize = 12.sp)
                            TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.worldaquatics.com/swimming/records"))) }) { Text("وب‌سایت World Aquatics") }
                            TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://dolfinoo.ir/records"))) }) { Text("آرشیو جدول‌های رکورد ایران (نیازمند بررسی سند") }
                        }
                    }
                }
                item { Text("نسخه آزمایشی؛ آخرین داده‌های واردشده با لینک منبع نمایش داده می‌شوند.", color = Color(0xFF7893AE), fontSize = 10.sp, modifier = Modifier.fillMaxWidth()) }
            }
        }
    }
}

@Composable
private fun ChoiceRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
        options.forEach { option ->
            FilterChip(selected = selected == option, onClick = { onSelect(option) }, label = { Text(option, fontSize = 11.sp) })
        }
    }
}
